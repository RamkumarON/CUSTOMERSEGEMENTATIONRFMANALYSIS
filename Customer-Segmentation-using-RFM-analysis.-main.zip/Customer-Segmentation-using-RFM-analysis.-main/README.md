# Customer-Segmentation-using-RFM-analysis.
RFM (Recency, Frequency, Monetary) analysis is a customer segmentation technique that uses past purchase behavior to divide customers into groups. RFM helps divide customers into various categories or clusters to identify customers who are more likely to respond to promotions and also for future personalization services.
Dealing with mystery out of big data and learn what it’s like to produce business results with the  data analytics team. -Assessing data quality and completeness for customer demographic and transaction data in preparation for analysis -Identifying high-value customers to optimize resource allocation for targeted marketing based on customer demographics and attributes -Utilizing Excel software to visualize large sets of data and present marketing and growth strategy insights to clients

<img width="960" alt="image3" src="https://user-images.githubusercontent.com/47268223/185776032-a11bbd31-fcf9-4053-a646-51b7da5e9ca2.png">
<img width="960" alt="image5" src="https://user-images.githubusercontent.com/47268223/185776033-c2d1e54a-4e6e-4ed5-8315-22ac2299b8af.png">
<img width="959" alt="image4 (1)" src="https://user-images.githubusercontent.com/47268223/185776052-22506b46-ac2c-4b06-bb13-d6c9d45053ae.png">
<img width="960" alt="image1" src="https://user-images.githubusercontent.com/47268223/185776024-95b98a77-0ecc-4b64-83a2-3f03a21412ba.png">
<img width="959" alt="image7" src="https://user-images.githubusercontent.com/47268223/185776028-0acfcdfa-56f8-4b5b-b495-01175f652d73.png">
<img width="960" alt="image2" src="https://user-images.githubusercontent.com/47268223/185776029-2e2d0218-d54f-426c-8fe4-11f5d48d9a8b.png">
